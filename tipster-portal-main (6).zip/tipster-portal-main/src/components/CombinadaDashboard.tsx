export { default } from './CombinadaCertificada';
